import React from 'react'
import Github from "C:/Users/Windows 10/Desktop/my-project/src/assets/github.svg"
// import HRI from './assets/HR.svg'

const Credit = () => {
    return (
        <div className='  w-full h-[20vh]  mx-auto text-center flex flex-col justify-center '>
            <footer className='flex justify-center '>
                <a href='https://github.com/SkylabMak/miningProject'>
                    <img src={Github} className="size-8" alt="github" />
                </a>
                <div className='text-xs flex flex-col items-start mx-3'>
                    <h1>project by 2nd year students</h1>
                    <a href='https://github.com/SkylabMak/miningProject'>
                        <h1>github :https://github.com/SkylabMak/miningProject</h1>
                    </a>
                </div>
            </footer>
        </div>
    );
};


export default Credit