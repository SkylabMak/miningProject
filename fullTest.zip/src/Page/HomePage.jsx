import { useState } from 'react'
import Home from './components/HomePage/home';
import Credit from './components/HomePage/credit';

function HomePage() {
    const [count, setCount] = useState(0)

    return (
        <>
            <Home />
            <Credit />

        </>
    )
}

export default HomePage
